<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


// Config variables

$config['mailsms'] = array(
     'student_admission'=> 'student_admission',
       'exam_result'=> 'exam_result',
       'fee_submission'=> 'fee_submission',
       'absent_attendence'=> 'absent_attendence',
       'login_credential'=> 'login_credential'
  );



$config['attendence'] = array(
       'present'=> 1,
       'late_with_excuse'=> 2,
       'late'=> 2,
       'absent'=> 4,
       'holiday'=> 5
  );


