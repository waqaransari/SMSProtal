<div class="content-wrapper" style="min-height: 1126px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Payment
        </h1>
    </section>

    <!-- Main content -->
    <section class="invoice">

        <div class="row">
            <div class="alert alert-warning alert-dismissible">

                <h4><i class="icon fa fa-warning"></i>Cancelled!</h4>
                You have cancelled this payment, please <a style='color: #3c8dbc;  display: inline-table;' href="<?php echo site_url('parent/parents/dashboard') ?>">click here</a> for Dashboard.
            </div>       
        </div>      
    </section>    
    <div class="clearfix"></div>
</div>